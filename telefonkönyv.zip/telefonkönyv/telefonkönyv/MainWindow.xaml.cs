﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace telefonkönyv
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            sql.Connect();
            sql.SelectName(lb1);
        }
        private void edit_Click(object sender, RoutedEventArgs e)
        {
            Other o = new Other();
            string s = "";
            try
            {
                s = sql.SelectOne(int.Parse(lb1.SelectedValue.ToString()));
            }
            catch (Exception)
            {
                MessageBox.Show("Válassz ki elötte valakit");
                return;
            }
            o.add.Content = "Módosít";
            string[] sp = s.Split(';');
            o.type = 1;
            o.id = int.Parse(lb1.SelectedValue.ToString());
            o.name.Text = sp[0];
            o.phone.Text = sp[1];
            o.cb.SelectedIndex = sp[2] == "Mobil" ? 1 : 0;
            o.ShowDialog();

            change_view();
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                sql.Delete(int.Parse(lb1.SelectedValue.ToString()));
            }
            catch (Exception)
            {
                MessageBox.Show("Válassz ki elötte valakit");
                return;
            }
            

            change_view();
        }

        private bool viewch = false;
        private void view_Click(object sender, RoutedEventArgs e)
        {
            if (viewch = !viewch)
            {
                sql.SelectAll(lb1);
                view.Content = "Minimalista nézet";
            }
            else
            {
                sql.SelectName(lb1);
                view.Content = "Részletes nézet";
            }
        }

        private void _new_Click(object sender, RoutedEventArgs e)
        {
            Other o = new Other();
            o.add.Content = "Hozzáad";
            o.type = 0;
            o.ShowDialog();
            change_view();
        }
        private void change_view()
        {
            if (viewch)
            {
                sql.SelectAll(lb1);
            }
            else
            {
                
                sql.SelectName(lb1);
            }
        }
    }
}
