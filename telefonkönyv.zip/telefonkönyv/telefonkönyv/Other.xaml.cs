﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace telefonkönyv
{
    /// <summary>
    /// Interaction logic for Other.xaml
    /// </summary>
    public partial class Other : Window
    {
        public Other()
        {
            InitializeComponent();
            cb.Items.Add("Vezetékes");
            cb.Items.Add("Mobil");
            cb.SelectedIndex = 0;
            add.Content = type == 0 ? "Hozzáad" : "Módosít";
        }
        public int type = 0;
        public int id = 0;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (name.Text.Length < 1)
            {
                MessageBox.Show("Nincs beírva név");
                return;
            }
            if (phone.Text.Length < 1)
            {
                MessageBox.Show("Nincs telefonszám név");
                return;
            }
            switch (type)
            {
                case 0:
                    sql.Insert(name.Text, phone.Text, cb.SelectedItem.ToString());
                    break;
                case 1:
                    sql.Update(id, name.Text, phone.Text, cb.SelectedItem.ToString());
                    break;
            }
            this.Close();
        }
    }
}
