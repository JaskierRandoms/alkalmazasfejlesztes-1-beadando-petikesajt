﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace telefonkönyv
{
    class sql
    {
        public static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");
        public static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.ToString());
            }
        }
        public static void Close()
        {
            try
            {
                conn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.ToString());
            }
        }
        public static void SelectAll(ListBox lb)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, CONCAT_WS(' ', name, number, type) as ossz  FROM contacts",conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["ossz"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }
        public static void SelectName(ListBox lb)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, name FROM contacts", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns[1].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }
        public static void Insert(string name, string phone, string type)
        {
            MySqlCommand cmd = new MySqlCommand("INSERT INTO `contacts`(`id`, `name`, `number`, `type`) VALUES (null,'" + name + "','" + phone + "','" + type + "')",conn);
            cmd.ExecuteNonQuery();
        }
        public static void Update(int id,string name, string phone, string type)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE `contacts` SET `name`='" + name + "',`number`='" + phone + "',`type`='" + type + "' WHERE id = '"+ id + "'", conn);
            cmd.ExecuteNonQuery();
        }
        public static string SelectOne(int id)
        {
            string s = "SELECT name,number,type FROM contacts WHERE id = '" + id + "'";
            MySqlCommand cmd = new MySqlCommand(s, conn);
            MySqlDataReader rd = cmd.ExecuteReader();
            string sr = "";
            if (rd.HasRows)
            {
                rd.Read();
                sr = rd.GetString(0) + ";" + rd.GetString(1) + ";" + rd.GetString(2);
            }
            rd.Close();
            return sr;
        }
        public static void Delete(int id)
        {
            string s = "DELETE FROM contacts WHERE id = '" + id + "'";
            MySqlCommand cmd = new MySqlCommand(s, conn);
            cmd.ExecuteNonQuery();
        }
    }
}
